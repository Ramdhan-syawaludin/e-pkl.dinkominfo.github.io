# PHP ZKLib #

Attendance Machine Library for PHP with a connection to the network using the UDP protocol and port 4370

> sorry I could not develop this library again because I already resigned from where I work and I do not have attendance machine to develop this library
